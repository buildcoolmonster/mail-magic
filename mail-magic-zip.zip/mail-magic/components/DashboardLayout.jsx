'use client';

import { signOut, useSession } from 'next-auth/react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
    LayoutDashboard,
    FileText,
    Users,
    Send,
    ListChecks,
    LogOut,
    Menu,
    X,
} from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';

const navigation = [
    { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    { name: 'Templates', href: '/templates', icon: FileText },
    { name: 'HR Emails', href: '/hr-emails', icon: Users },
    { name: 'Send Emails', href: '/send', icon: Send },
    { name: 'Logs', href: '/logs', icon: ListChecks },
];

export default function DashboardLayout({ children }) {
    const { data: session } = useSession();
    const pathname = usePathname();
    const [sidebarOpen, setSidebarOpen] = useState(false);

    return (
        <div className="min-h-screen bg-background">
            {/* Mobile sidebar */}
            <div
                className={cn(
                    'fixed inset-0 z-50 lg:hidden transition-opacity',
                    sidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
                )}
            >
                <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
                <div
                    className={cn(
                        'absolute inset-y-0 left-0 w-64 glass-card transition-transform',
                        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
                    )}
                >
                    <div className="flex flex-col h-full p-6">
                        <button
                            onClick={() => setSidebarOpen(false)}
                            className="absolute top-4 right-4 p-2 rounded-lg hover:bg-muted"
                        >
                            <X className="w-5 h-5" />
                        </button>
                        <SidebarContent pathname={pathname} />
                    </div>
                </div>
            </div>

            {/* Desktop sidebar */}
            <div className="hidden lg:fixed lg:inset-y-0 lg:flex lg:w-64 lg:flex-col">
                <div className="flex flex-col flex-grow glass-card m-4 rounded-2xl p-6">
                    <SidebarContent pathname={pathname} />
                </div>
            </div>

            {/* Main content */}
            <div className="lg:pl-64">
                {/* Top bar */}
                <div className="sticky top-0 z-40 glass backdrop-blur-xl border-b border-border/50">
                    <div className="flex items-center justify-between px-4 py-4 lg:px-8">
                        <button
                            onClick={() => setSidebarOpen(true)}
                            className="lg:hidden p-2 rounded-lg hover:bg-muted"
                        >
                            <Menu className="w-6 h-6" />
                        </button>

                        <div className="flex-1 lg:ml-0 ml-4">
                            <h1 className="text-xl font-bold gradient-text">AutoJobMailer</h1>
                        </div>

                        <div className="flex items-center gap-4">
                            <div className="text-right hidden sm:block">
                                <p className="text-sm font-medium">{session?.user?.name}</p>
                                <p className="text-xs text-muted-foreground">{session?.user?.email}</p>
                            </div>
                            <img
                                src={session?.user?.image || '/placeholder-avatar.png'}
                                alt={session?.user?.name || 'User'}
                                className="w-10 h-10 rounded-full ring-2 ring-primary/20"
                            />
                            <button
                                onClick={() => signOut({ callbackUrl: '/' })}
                                className="p-2 rounded-lg hover:bg-destructive/10 hover:text-destructive transition-colors"
                                title="Sign out"
                            >
                                <LogOut className="w-5 h-5" />
                            </button>
                        </div>
                    </div>
                </div>

                {/* Page content */}
                <main className="p-4 lg:p-8">
                    {children}
                </main>
            </div>
        </div>
    );
}

function SidebarContent({ pathname }) {
    return (
        <>
            <div className="mb-8">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl gradient-bg-primary flex items-center justify-center glow-primary">
                        <Send className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <h2 className="font-bold gradient-text">AutoJobMailer</h2>
                        <p className="text-xs text-muted-foreground">Job Application Automation</p>
                    </div>
                </div>
            </div>

            <nav className="flex-1 space-y-2">
                {navigation.map((item) => {
                    const isActive = pathname === item.href;
                    return (
                        <Link
                            key={item.name}
                            href={item.href}
                            className={cn(
                                'flex items-center gap-3 px-4 py-3 rounded-lg transition-all hover-lift',
                                isActive
                                    ? 'gradient-bg-primary text-white glow-primary'
                                    : 'hover:bg-muted text-muted-foreground hover:text-foreground'
                            )}
                        >
                            <item.icon className="w-5 h-5" />
                            <span className="font-medium">{item.name}</span>
                        </Link>
                    );
                })}
            </nav>

            <div className="mt-auto pt-6 border-t border-border">
                <div className="glass-card p-4 rounded-lg">
                    <p className="text-xs font-medium text-muted-foreground mb-2">Need Help?</p>
                    <p className="text-xs text-muted-foreground">
                        Check out our{' '}
                        <a href="#" className="text-primary hover:underline">
                            documentation
                        </a>
                    </p>
                </div>
            </div>
        </>
    );
}
