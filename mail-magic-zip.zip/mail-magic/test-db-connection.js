// Test MongoDB Connection
// Run with: node test-db-connection.js

const mongoose = require('mongoose');

// Replace with your MongoDB connection string from .env.local
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/autojobmailer';

async function testConnection() {
    console.log('🔌 Testing MongoDB connection...\n');

    try {
        // Connect to MongoDB
        console.log('📡 Connecting to:', MONGODB_URI.replace(/:[^:@]+@/, ':****@'));
        await mongoose.connect(MONGODB_URI);

        console.log('✅ MongoDB connected successfully!\n');

        // Get database name
        const dbName = mongoose.connection.db.databaseName;
        console.log('📊 Database name:', dbName);

        // List collections
        const collections = await mongoose.connection.db.listCollections().toArray();
        console.log('📁 Collections:', collections.length > 0 ? collections.map(c => c.name).join(', ') : 'No collections yet (will be created automatically)');

        // Test a simple operation
        const testSchema = new mongoose.Schema({ test: String });
        const TestModel = mongoose.model('Test', testSchema);

        console.log('\n🧪 Testing database write...');
        const doc = await TestModel.create({ test: 'Connection test successful!' });
        console.log('✅ Write successful! Document ID:', doc._id);

        console.log('\n🧹 Cleaning up test data...');
        await TestModel.deleteOne({ _id: doc._id });
        console.log('✅ Cleanup complete!');

        // Connection stats
        console.log('\n📈 Connection details:');
        console.log('   - Host:', mongoose.connection.host);
        console.log('   - Port:', mongoose.connection.port);
        console.log('   - Ready state:', mongoose.connection.readyState === 1 ? 'Connected' : 'Not connected');

        await mongoose.connection.close();
        console.log('\n👋 Connection closed gracefully');
        console.log('\n🎉 All tests passed! Your MongoDB is ready to use!\n');

    } catch (error) {
        console.error('\n❌ MongoDB connection error:\n');

        if (error.name === 'MongooseServerSelectionError') {
            console.error('   → Cannot connect to MongoDB server');
            console.error('   → Check your connection string and network access');
            console.error('   → Ensure IP 0.0.0.0/0 is whitelisted in MongoDB Atlas');
        } else if (error.name === 'MongoParseError') {
            console.error('   → Invalid connection string format');
            console.error('   → Check your MONGODB_URI in .env.local');
        } else if (error.message.includes('Authentication failed')) {
            console.error('   → Database username or password is incorrect');
            console.error('   → Verify credentials in MongoDB Atlas');
        } else {
            console.error('   Error:', error.message);
        }

        console.error('\n💡 Troubleshooting tips:');
        console.error('   1. Check .env.local file exists with MONGODB_URI');
        console.error('   2. Verify MongoDB Atlas cluster is running');
        console.error('   3. Check network access allows 0.0.0.0/0');
        console.error('   4. Verify database user credentials');
        console.error('   5. See MONGODB_SETUP.md for detailed instructions\n');

        process.exit(1);
    }
}

// Run the test
console.log('╔════════════════════════════════════════════╗');
console.log('║   AutoJobMailer - MongoDB Connection Test ║');
console.log('╚════════════════════════════════════════════╝\n');

testConnection();
