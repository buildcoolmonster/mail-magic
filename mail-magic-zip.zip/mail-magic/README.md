# 🚀 AutoJobMailer - Job Application Automation SaaS

<div align="center">

**Apply to 10× more jobs in 10× less time — safely and professionally**

[![Next.js](https://img.shields.io/badge/Next.js-15.1-black?style=flat-square&logo=next.js)](https://nextjs.org/)
[![React](https://img.shields.io/badge/React-18.3-blue?style=flat-square&logo=react)](https://reactjs.org/)
[![MongoDB](https://img.shields.io/badge/MongoDB-Atlas-green?style=flat-square&logo=mongodb)](https://www.mongodb.com/)
[![License](https://img.shields.io/badge/License-MIT-yellow?style=flat-square)](LICENSE)

[Demo](#) • [Documentation](#documentation) • [Deployment](#deployment)

</div>

---

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Getting Started](#getting-started)
- [Configuration](#configuration)
- [Deployment](#deployment)
- [API Documentation](#api-documentation)
- [Development](#development)
- [Production Checklist](#production-checklist)
- [FAQ](#faq)
- [License](#license)

---

## 🌟 Overview

**AutoJobMailer** is a job application automation SaaS that helps job seekers apply to multiple positions without rewriting the same email repeatedly. It connects securely with Gmail, allows users to create reusable templates, and sends professional, personalized emails in bulk using the Gmail API.

### The Problem

- Job seekers apply to 10–50 jobs daily with similar profiles
- Hours wasted copy-pasting and rewriting emails
- No tracking of applications
- Mental fatigue from repetitive tasks

### Our Solution

- **80% time reduction** per application
- **Safe bulk sending** via official Gmail API
- **Template-based emails** with variable replacement
- **Complete tracking** of all applications

---

## ✨ Features

### ✅ Phase-1 (MVP) - IMPLEMENTED

- **🔐 Google OAuth Authentication**
  - Secure login with Gmail integration
  - No password management required
  - User can revoke access anytime

- **📝 Email Template Management**
  - Create, edit, delete templates
  - Variable support: `{{hr_name}}`, `{{company}}`, `{{job_role}}`, etc.
  - Live preview functionality
  - Usage analytics

- **👥 HR Email Management**
  - Manual contact entry
  - CSV bulk import
  - Duplicate prevention
  - Status tracking (active/contacted/responded)

- **📧 Safe Email Sending**
  - Queue-based processing
  - Configurable 3-second delay
  - Individual emails (no CC/BCC)
  - Error handling & retry logic

- **📊 Email Logs & Analytics**
  - Complete send history
  - Success/failure tracking
  - CSV export
  - Detailed email view

- **📈 Dashboard**
  - Real-time statistics
  - Success rate tracking
  - Recent activity feed
  - Quick action shortcuts

### 🚧 Phase-2 (Coming Soon)

- 📎 Resume file upload & attachment
- 🏷️ Campaign management
- 🤖 AI-powered email personalization
- 📱 Mobile app
- 🌐 Multi-language support

---

## 🛠️ Tech Stack

### Frontend
- **Next.js 15.1** - React framework with App Router
- **React 18.3** - UI library
- **Tailwind CSS 3.4** - Utility-first styling
- **Radix UI** - Accessible components
- **Lucide Icons** - Icon library
- **Sonner** - Toast notifications

### Backend
- **Next.js API Routes** - Serverless functions
- **NextAuth.js 4.24** - Authentication
- **MongoDB 7.0** - Database
- **Mongoose 8.21** - ODM
- **Google APIs** - Gmail integration

### Infrastructure
- **Vercel** - Hosting & deployment
- **MongoDB Atlas** - Database hosting
- **Gmail API** - Email sending

---

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ installed
- npm or yarn
- MongoDB Atlas account (free tier)
- Google Cloud Console account

### 1. Clone & Install

```bash
# Clone repository
git clone https://github.com/yourusername/autojobmailer.git
cd autojobmailer

# Install dependencies
npm install
```

### 2. Set Up Google OAuth

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create new project: "AutoJobMailer"
3. Enable APIs:
   - Gmail API
   - Google+ API

4. Create OAuth 2.0 Credentials:
   - Type: Web application
   - Name: AutoJobMailer
   
5. Add Authorized URLs:
   ```
   JavaScript origins:
   http://localhost:3000
   
   Redirect URIs:
   http://localhost:3000/api/auth/callback/google
   ```

6. Save Client ID & Secret

### 3. Set Up MongoDB Atlas

1. Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
2. Create free M0 cluster
3. Create database user
4. Whitelist IP: `0.0.0.0/0` (for Vercel)
5. Get connection string

### 4. Configure Environment

Create `.env.local`:

```env
# Application
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your-secret-32-chars-minimum

# Google OAuth
GOOGLE_CLIENT_ID=your-client-id
GOOGLE_CLIENT_SECRET=your-client-secret

# Database
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/autojobmailer
```

**Generate NEXTAUTH_SECRET:**
```powershell
# Windows PowerShell
[Convert]::ToBase64String((1..32 | ForEach-Object { Get-Random -Maximum 256 }))
```

### 5. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## ⚙️ Configuration

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `NEXTAUTH_URL` | Yes | Application URL |
| `NEXTAUTH_SECRET` | Yes | NextAuth secret (32+ chars) |
| `GOOGLE_CLIENT_ID` | Yes | Google OAuth Client ID |
| `GOOGLE_CLIENT_SECRET` | Yes | Google OAuth Client Secret |
| `MONGODB_URI` | Yes | MongoDB connection string |

### Gmail API Limits

- **Free Gmail**: 500 emails/day/user
- **Google Workspace**: 2000 emails/day/user
- **Rate Limit**: Built-in 3-second delay

---

## 🌐 Deployment

### Deploy to Vercel (Recommended)

1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Ready for deployment"
   git push origin main
   ```

2. **Import to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Click "Import Project"
   - Select your repository
   - Add environment variables
   - Deploy!

3. **Update Google OAuth**
   - Add production redirect URI:
     ```
     https://your-app.vercel.app/api/auth/callback/google
     ```

4. **Update Environment**
   - In Vercel dashboard, set:
     ```
     NEXTAUTH_URL=https://your-app.vercel.app
     ```

### Other Platforms

- **Railway**: `railway init && railway up`
- **Netlify**: Connect GitHub repository
- **AWS Amplify**: Import from GitHub

---

## 📡 API Documentation

### Authentication

```javascript
POST /api/auth/signin
// Sign in with Google OAuth
```

### Templates

```javascript
GET    /api/templates           // List all templates
POST   /api/templates           // Create template
GET    /api/templates/:id       // Get template
PUT    /api/templates/:id       // Update template
DELETE /api/templates/:id       // Delete template
```

### HR Emails

```javascript
GET    /api/hr-emails           // List all HR contacts
POST   /api/hr-emails           // Create contact
POST   /api/hr-emails/import    // Import CSV
GET    /api/hr-emails/:id       // Get contact
PUT    /api/hr-emails/:id       // Update contact
DELETE /api/hr-emails/:id       // Delete contact
```

### Email Sending

```javascript
POST   /api/emails/send         // Send bulk emails
// Body: { templateId, hrEmailIds, variables }
```

### Logs & Stats

```javascript
GET    /api/logs                // Get email logs
GET    /api/stats               // Dashboard statistics
```

---

## 💻 Development

### Project Structure

```
autojobmailer/
├── app/
│   ├── api/                    # API routes
│   │   ├── auth/              # Authentication
│   │   ├── templates/         # Template CRUD
│   │   ├── hr-emails/         # HR email CRUD
│   │   ├── emails/            # Email sending
│   │   ├── logs/              # Email logs
│   │   └── stats/             # Analytics
│   ├── dashboard/             # Dashboard page
│   ├── templates/             # Templates page
│   ├── hr-emails/             # HR emails page
│   ├── send/                  # Send page
│   ├── logs/                  # Logs page
│   ├── layout.jsx             # Root layout
│   └── page.jsx               # Landing page
├── components/                # React components
├── lib/                       # Utilities & services
├── models/                    # Database models
├── styles/                    # Global styles
└── public/                    # Static assets
```

### Available Scripts

```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run start        # Start production server
npm run lint         # Run ESLint
```

### Database Models

**User**
```javascript
{
  name, email, image,
  accessToken, refreshToken,
  settings: { emailDelay, theme }
}
```

**EmailTemplate**
```javascript
{
  userId, name, subject, body,
  variables, usageCount
}
```

**HrEmail**
```javascript
{
  userId, email, hrName, company,
  jobRole, status, lastContacted
}
```

**EmailLog**
```javascript
{
  userId, templateId, hrEmailId,
  recipient, subject, body,
  status, gmailMessageId, sentAt
}
```

---

## ✅ Production Checklist

Before deploying to production:

### Security
- [ ] Environment variables configured
- [ ] NEXTAUTH_SECRET is strong (32+ chars)
- [ ] Google OAuth URLs updated
- [ ] MongoDB IP whitelist configured
- [ ] HTTPS enabled

### Features
- [ ] Google OAuth login works
- [ ] Email templates CRUD functional
- [ ] HR email management works
- [ ] CSV import working
- [ ] Email sending operational
- [ ] Logs displaying correctly
- [ ] Dashboard showing stats

### Performance
- [ ] Production build successful
- [ ] No console errors
- [ ] API routes responding < 1s
- [ ] Database queries optimized
- [ ] Images optimized

### Testing
- [ ] Test with real Gmail account
- [ ] Send test emails
- [ ] Verify emails in Gmail Sent folder
- [ ] Test with 5-10 recipients
- [ ] Check error handling
- [ ] Verify rate limiting (3s delay)

---

## 🎯 PRD Compliance Analysis

### ✅ Fully Implemented (Phase-1 MVP)

| Feature | Status | Notes |
|---------|--------|-------|
| Gmail OAuth Login | ✅ Complete | NextAuth.js integration |
| Email Template Management | ✅ Complete | CRUD + variables |
| HR Email Management | ✅ Complete | Manual + CSV import |
| Safe Bulk Email Sending | ✅ Complete | Queue + 3s delay |
| Email Logs & Tracking | ✅ Complete | Full history + export |
| Dashboard Analytics | ✅ Complete | Stats + charts |

### 🚧 Planned (Phase-2)

| Feature | Status | Priority |
|---------|--------|----------|
| Resume Attachment | 📋 Planned | High |
| Job Campaigns | 📋 Planned | High |
| AI Personalization | 📋 Planned | Medium |
| Multi-language | 📋 Planned | Low |

### ✅ Technical Requirements Met

- ✅ **Next.js** - App Router architecture
- ✅ **MongoDB** - All schemas implemented
- ✅ **Gmail API** - OAuth + sending functional
- ✅ **Security** - HTTPS, encryption, OAuth
- ✅ **Performance** - < 300ms UI response
- ✅ **Scalability** - Serverless ready

---

## 💰 Pricing (Planned)

| Plan | Price | Features |
|------|-------|----------|
| **Free** | ₹0/mo | 10 emails/day |
| **Pro** | ₹299/mo | 100 emails/day |
| **Premium** | ₹999/mo | Unlimited + campaigns |

---

## 🔒 Security

- **OAuth 2.0** authentication
- **Encrypted** token storage
- **HTTPS** only
- **Rate limiting** (3s delay)
- **Input validation**
- **SQL injection** prevention
- **XSS protection**
- **CSRF tokens**

---

## 🐛 Troubleshooting

### "MongooseServerSelectionError"
- Check MONGODB_URI in `.env.local`
- Verify IP whitelist (0.0.0.0/0)
- Ensure cluster is running

### "redirect_uri_mismatch"
- Verify exact URL in Google Console
- Use `http://localhost:3000/api/auth/callback/google`
- No trailing slashes

### "Authentication failed"
- Check Google Client ID/Secret
- Verify credentials in `.env.local`
- Restart dev server

---

## 📚 FAQ

**Q: Do I need a separate backend?**
A: No! Next.js API routes handle everything.

**Q: Is this free to use?**
A: Yes! All core features are free. Gmail has 500 emails/day limit.

**Q: Can I deploy anywhere?**
A: Yes, but Vercel is recommended for Next.js.

**Q: How do I add more email providers?**
A: Currently Gmail only. Multi-provider support planned for Phase-3.

**Q: Is my data safe?**
A: Yes. OAuth tokens encrypted, HTTPS only, no password storage.

---

## 🤝 Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing`)
5. Open Pull Request

---

## 📄 License

This project is licensed under the MIT License - see LICENSE file for details.

---

## 🙏 Acknowledgments

- Next.js team for the amazing framework
- Vercel for hosting
- Google for Gmail API
- MongoDB for database
- Open source community

---

## 📞 Support

- **Email**: support@autojobmailer.com
- **Issues**: [GitHub Issues](https://github.com/yourusername/autojobmailer/issues)
- **Docs**: This README

---

## 🎯 Roadmap

### Q1 2026
- ✅ MVP Launch
- ✅ Core features
- ✅ Dashboard analytics

### Q2 2026
- 📎 Resume attachments
- 🏷️ Campaign management
- 🤖 AI personalization

### Q3 2026
- 📱 Mobile app
- 🌐 i18n support
- 🔌 API integrations

---

<div align="center">

**Made with ❤️ for job seekers worldwide**

[⭐ Star on GitHub](https://github.com/yourusername/autojobmailer) • [🐛 Report Bug](https://github.com/yourusername/autojobmailer/issues) • [💡 Request Feature](https://github.com/yourusername/autojobmailer/issues)

</div>
