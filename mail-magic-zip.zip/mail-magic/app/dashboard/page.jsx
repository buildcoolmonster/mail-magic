'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import ProtectedRoute from '@/components/ProtectedRoute';
import DashboardLayout from '@/components/DashboardLayout';
import {
    BarChart3,
    TrendingUp,
    Mail,
    FileText,
    Users,
    CheckCircle2,
    XCircle,
    ArrowUpRight,
} from 'lucide-react';
import { toast } from 'sonner';
import Link from 'next/link';

export default function DashboardPage() {
    const { data: session } = useSession();
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchStats();
    }, []);

    const fetchStats = async () => {
        try {
            const response = await fetch('/api/stats');
            if (response.ok) {
                const data = await response.json();
                setStats(data);
            } else {
                toast.error('Failed to load statistics');
            }
        } catch (error) {
            console.error('Error fetching stats:', error);
            toast.error('Failed to load statistics');
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <ProtectedRoute>
                <DashboardLayout>
                    <div className="flex items-center justify-center h-64">
                        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                    </div>
                </DashboardLayout>
            </ProtectedRoute>
        );
    }

    const statCards = [
        {
            name: 'Total Templates',
            value: stats?.stats?.totalTemplates || 0,
            icon: FileText,
            color: 'primary',
            link: '/templates',
        },
        {
            name: 'HR Contacts',
            value: stats?.stats?.totalHrEmails || 0,
            icon: Users,
            color: 'accent',
            link: '/hr-emails',
        },
        {
            name: 'Emails Sent',
            value: stats?.stats?.totalEmailsSent || 0,
            icon: CheckCircle2,
            color: 'success',
            link: '/logs',
        },
        {
            name: 'Failed',
            value: stats?.stats?.totalEmailsFailed || 0,
            icon: XCircle,
            color: 'destructive',
            link: '/logs',
        },
    ];

    return (
        <ProtectedRoute>
            <DashboardLayout>
                <div className="max-w-7xl mx-auto space-y-8 animate-fade-in">
                    {/* Header */}
                    <div>
                        <h1 className="text-3xl font-bold mb-2">
                            Welcome back, <span className="gradient-text">{session?.user?.name?.split(' ')[0]}</span>! 👋
                        </h1>
                        <p className="text-muted-foreground">
                            Here's what's happening with your job applications today.
                        </p>
                    </div>

                    {/* Stats Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        {statCards.map((stat, index) => (
                            <Link
                                key={stat.name}
                                href={stat.link}
                                className="glass-card p-6 hover-lift card-hover animate-scale-in"
                                style={{ animationDelay: `${index * 50}ms` }}
                            >
                                <div className="flex items-center justify-between mb-4">
                                    <div className={`w-12 h-12 rounded-xl gradient-bg-${stat.color} flex items-center justify-center`}>
                                        <stat.icon className="w-6 h-6 text-white" />
                                    </div>
                                    <ArrowUpRight className="w-5 h-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                                </div>
                                <p className="text-2xl font-bold mb-1">{stat.value}</p>
                                <p className="text-sm text-muted-foreground">{stat.name}</p>
                            </Link>
                        ))}
                    </div>

                    {/* Success Rate */}
                    {stats && (stats.stats.totalEmailsSent + stats.stats.totalEmailsFailed) > 0 && (
                        <div className="glass-card p-6">
                            <div className="flex items-center justify-between mb-4">
                                <div>
                                    <h3 className="text-lg font-semibold mb-1">Success Rate</h3>
                                    <p className="text-sm text-muted-foreground">Email delivery performance</p>
                                </div>
                                <TrendingUp className="w-8 h-8 text-green-500" />
                            </div>
                            <div className="space-y-3">
                                <div className="flex items-center justify-between">
                                    <span className="text-3xl font-bold gradient-text">{stats.stats.successRate}%</span>
                                    <span className="text-sm text-muted-foreground">
                                        {stats.stats.totalEmailsSent} / {stats.stats.totalEmailsSent + stats.stats.totalEmailsFailed} emails
                                    </span>
                                </div>
                                <div className="w-full h-3 bg-muted rounded-full overflow-hidden">
                                    <div
                                        className="h-full gradient-bg-success transition-all duration-500"
                                        style={{ width: `${stats.stats.successRate}%` }}
                                    />
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Recent Activity */}
                    <div className="glass-card p-6">
                        <div className="flex items-center justify-between mb-6">
                            <div>
                                <h3 className="text-lg font-semibold mb-1">Recent Activity</h3>
                                <p className="text-sm text-muted-foreground">Latest email logs</p>
                            </div>
                            <Link href="/logs" className="text-sm text-primary hover:underline flex items-center gap-1">
                                View all
                                <ArrowUpRight className="w-4 h-4" />
                            </Link>
                        </div>

                        {stats?.recentLogs && stats.recentLogs.length > 0 ? (
                            <div className="space-y-3">
                                {stats.recentLogs.map((log) => (
                                    <div
                                        key={log._id}
                                        className="flex items-center gap-4 p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                                    >
                                        {log.status === 'sent' ? (
                                            <CheckCircle2 className="w-5 h-5 text-green-500" />
                                        ) : (
                                            <XCircle className="w-5 h-5 text-red-500" />
                                        )}
                                        <div className="flex-1 min-w-0">
                                            <p className="font-medium truncate">{log.recipient}</p>
                                            <p className="text-sm text-muted-foreground truncate">{log.subject}</p>
                                        </div>
                                        <div className="text-right">
                                            <p className="text-sm text-muted-foreground">
                                                {new Date(log.createdAt).toLocaleDateString()}
                                            </p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="text-center py-12">
                                <Mail className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                                <p className="text-muted-foreground">No recent activity</p>
                                <Link href="/send" className="text-sm text-primary hover:underline mt-2 inline-block">
                                    Send your first email
                                </Link>
                            </div>
                        )}
                    </div>

                    {/* Quick Actions */}
                    <div className="grid md:grid-cols-3 gap-6">
                        <Link
                            href="/templates"
                            className="glass-card p-6 hover-lift card-hover group"
                        >
                            <FileText className="w-8 h-8 text-primary mb-4 group-hover:scale-110 transition-transform" />
                            <h3 className="font-semibold mb-2">Create Template</h3>
                            <p className="text-sm text-muted-foreground">Build a new email template with variables</p>
                        </Link>

                        <Link
                            href="/hr-emails"
                            className="glass-card p-6 hover-lift card-hover group"
                        >
                            <Users className="w-8 h-8 text-accent mb-4 group-hover:scale-110 transition-transform" />
                            <h3 className="font-semibold mb-2">Add HR Contacts</h3>
                            <p className="text-sm text-muted-foreground">Manage your HR email list</p>
                        </Link>

                        <Link
                            href="/send"
                            className="glass-card p-6 hover-lift card-hover group gradient-bg-primary text-white"
                        >
                            <Mail className="w-8 h-8 mb-4 group-hover:scale-110 transition-transform" />
                            <h3 className="font-semibold mb-2">Send Emails</h3>
                            <p className="text-sm opacity-90">Start sending job applications now</p>
                        </Link>
                    </div>
                </div>
            </DashboardLayout>
        </ProtectedRoute>
    );
}
