'use client';

import { useEffect, useState } from 'react';
import ProtectedRoute from '@/components/ProtectedRoute';
import DashboardLayout from '@/components/DashboardLayout';
import { Send, CheckCircle, FileText, Users, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { replaceVariables } from '@/lib/utils';

export default function SendEmailsPage() {
    const [templates, setTemplates] = useState([]);
    const [hrEmails, setHrEmails] = useState([]);
    const [selectedTemplate, setSelectedTemplate] = useState('');
    const [selectedHrEmails, setSelectedHrEmails] = useState([]);
    const [variables, setVariables] = useState({
        your_name: '',
        resume_link: '',
        portfolio_link: '',
    });
    const [sending, setSending] = useState(false);
    const [preview, setPreview] = useState(null);

    useEffect(() => {
        fetchTemplates();
        fetchHrEmails();
    }, []);

    const fetchTemplates = async () => {
        try {
            const response = await fetch('/api/templates');
            if (response.ok) {
                const data = await response.json();
                setTemplates(data);
            }
        } catch (error) {
            console.error('Error:', error);
        }
    };

    const fetchHrEmails = async () => {
        try {
            const response = await fetch('/api/hr-emails');
            if (response.ok) {
                const data = await response.json();
                setHrEmails(data);
            }
        } catch (error) {
            console.error('Error:', error);
        }
    };

    const handleSend = async () => {
        if (!selectedTemplate) {
            toast.error('Please select a template');
            return;
        }

        if (selectedHrEmails.length === 0) {
            toast.error('Please select at least one recipient');
            return;
        }

        if (!variables.your_name) {
            toast.error('Please enter your name');
            return;
        }

        if (!confirm(`Send emails to ${selectedHrEmails.length} recipient(s)?`)) {
            return;
        }

        setSending(true);

        try {
            const response = await fetch('/api/emails/send', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    templateId: selectedTemplate,
                    hrEmailIds: selectedHrEmails,
                    variables,
                }),
            });

            if (response.ok) {
                const result = await response.json();
                toast.success(`Successfully sent ${result.results.sent.length} emails!`);
                if (result.results.failed.length > 0) {
                    toast.error(`${result.results.failed.length} emails failed to send`);
                }
                // Reset form
                setSelectedHrEmails([]);
            } else {
                const error = await response.json();
                toast.error(error.error || 'Failed to send emails');
            }
        } catch (error) {
            console.error('Error:', error);
            toast.error('Something went wrong');
        } finally {
            setSending(false);
        }
    };

    const handlePreview = () => {
        const template = templates.find((t) => t._id === selectedTemplate);
        if (!template) return;

        const sampleHrEmail = hrEmails.find((hr) => selectedHrEmails.includes(hr._id));
        if (!sampleHrEmail) return;

        const previewVars = {
            ...variables,
            hr_name: sampleHrEmail.hrName || 'Hiring Manager',
            company: sampleHrEmail.company || 'Company Name',
            job_role: sampleHrEmail.jobRole || 'Position',
        };

        setPreview({
            subject: replaceVariables(template.subject, previewVars),
            body: replaceVariables(template.body, previewVars),
        });
    };

    const toggleSelectAll = () => {
        if (selectedHrEmails.length === hrEmails.length) {
            setSelectedHrEmails([]);
        } else {
            setSelectedHrEmails(hrEmails.map((hr) => hr._id));
        }
    };

    const selectedTemplate Obj = templates.find((t) => t._id === selectedTemplate);

    return (
        <ProtectedRoute>
            <DashboardLayout>
                <div className="max-w-7xl mx-auto animate-fade-in">
                    {/* Header */}
                    <div className="mb-8">
                        <h1 className="text-3xl font-bold mb-2 gradient-text">Send Emails</h1>
                        <p className="text-muted-foreground">
                            Select a template and recipients to send personalized job applications
                        </p>
                    </div>

                    <div className="grid lg:grid-cols-3 gap-6">
                        {/* Left Column - Configuration */}
                        <div className="lg:col-span-2 space-y-6">
                            {/* Template Selection */}
                            <div className="glass-card p-6">
                                <div className="flex items-center gap-3 mb-4">
                                    <div className="w-10 h-10 rounded-xl gradient-bg-primary flex items-center justify-center">
                                        <FileText className="w-5 h-5 text-white" />
                                    </div>
                                    <h2 className="text-xl font-semibold">1. Select Template</h2>
                                </div>

                                {templates.length === 0 ? (
                                    <p className="text-muted-foreground">No templates available. Create one first.</p>
                                ) : (
                                    <select
                                        value={selectedTemplate}
                                        onChange={(e) => setSelectedTemplate(e.target.value)}
                                        className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                    >
                                        <option value="">Choose a template...</option>
                                        {templates.map((template) => (
                                            <option key={template._id} value={template._id}>
                                                {template.name}
                                            </option>
                                        ))}
                                    </select>
                                )}
                            </div>

                            {/* Variable Inputs */}
                            {selectedTemplateObj && (
                                <div className="glass-card p-6 animate-scale-in">
                                    <h2 className="text-xl font-semibold mb-4">2. Fill Variables</h2>
                                    <div className="space-y-4">
                                        <div>
                                            <label className="block text-sm font-medium mb-2">Your Name *</label>
                                            <input
                                                type="text"
                                                value={variables.your_name}
                                                onChange={(e) => setVariables({ ...variables, your_name: e.target.value })}
                                                className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                                placeholder="John Doe"
                                            />
                                        </div>

                                        <div>
                                            <label className="block text-sm font-medium mb-2">Resume Link</label>
                                            <input
                                                type="url"
                                                value={variables.resume_link}
                                                onChange={(e) => setVariables({ ...variables, resume_link: e.target.value })}
                                                className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                                placeholder="https://drive.google.com/..."
                                            />
                                        </div>

                                        <div>
                                            <label className="block text-sm font-medium mb-2">Portfolio Link</label>
                                            <input
                                                type="url"
                                                value={variables.portfolio_link}
                                                onChange={(e) => setVariables({ ...variables, portfolio_link: e.target.value })}
                                                className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                                placeholder="https://yourportfolio.com"
                                            />
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* Recipients Selection */}
                            <div className="glass-card p-6">
                                <div className="flex items-center justify-between mb-4">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-xl gradient-bg-accent flex items-center justify-center">
                                            <Users className="w-5 h-5 text-white" />
                                        </div>
                                        <h2 className="text-xl font-semibold">3. Select Recipients</h2>
                                    </div>
                                    <button
                                        onClick={toggleSelectAll}
                                        className="text-sm text-primary hover:underline"
                                    >
                                        {selectedHrEmails.length === hrEmails.length ? 'Deselect All' : 'Select All'}
                                    </button>
                                </div>

                                {hrEmails.length === 0 ? (
                                    <p className="text-muted-foreground">No HR contacts available. Add some first.</p>
                                ) : (
                                    <div className="space-y-2 max-h-96 overflow-y-auto">
                                        {hrEmails.map((hr) => (
                                            <label
                                                key={hr._id}
                                                className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                                            >
                                                <input
                                                    type="checkbox"
                                                    checked={selectedHrEmails.includes(hr._id)}
                                                    onChange={(e) => {
                                                        if (e.target.checked) {
                                                            setSelectedHrEmails([...selectedHrEmails, hr._id]);
                                                        } else {
                                                            setSelectedHrEmails(selectedHrEmails.filter((id) => id !== hr._id));
                                                        }
                                                    }}
                                                    className="w-5 h-5 rounded border-2 border-primary text-primary focus:ring-2 focus:ring-primary/20"
                                                />
                                                <div className="flex-1 min-w-0">
                                                    <p className="font-medium truncate">{hr.email}</p>
                                                    <p className="text-sm text-muted-foreground truncate">
                                                        {hr.hrName || 'No name'} • {hr.company || 'No company'}
                                                    </p>
                                                </div>
                                            </label>
                                        ))}
                                    </div>
                                )}

                                {selectedHrEmails.length > 0 && (
                                    <div className="mt-4 pt-4 border-t border-border/50">
                                        <p className="text-sm text-muted-foreground">
                                            <span className="font-semibold text-foreground">{selectedHrEmails.length}</span> recipient(s) selected
                                        </p>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Right Column - Preview & Send */}
                        <div className="space-y-6">
                            {/* Preview */}
                            <div className="glass-card p-6 sticky top-24">
                                <h2 className="text-xl font-semibold mb-4">Email Preview</h2>

                                {!selectedTemplate || selectedHrEmails.length === 0 ? (
                                    <div className="text-center py-12">
                                        <Send className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                                        <p className="text-muted-foreground text-sm">
                                            Select a template and recipients to preview
                                        </p>
                                    </div>
                                ) : (
                                    <>
                                        <button
                                            onClick={handlePreview}
                                            className="w-full px-4 py-2 rounded-lg border border-border hover:bg-muted transition-colors mb-4"
                                        >
                                            Generate Preview
                                        </button>

                                        {preview && (
                                            <div className="space-y-4 animate-scale-in">
                                                <div>
                                                    <p className="text-xs font-medium text-muted-foreground mb-2">Subject:</p>
                                                    <p className="text-sm font-medium">{preview.subject}</p>
                                                </div>
                                                <div>
                                                    <p className="text-xs font-medium text-muted-foreground mb-2">Body:</p>
                                                    <div className="p-4 rounded-lg bg-muted/50 text-sm whitespace-pre-wrap max-h-64 overflow-y-auto">
                                                        {preview.body}
                                                    </div>
                                                </div>
                                            </div>
                                        )}
                                    </>
                                )}

                                {/* Send Button */}
                                <button
                                    onClick={handleSend}
                                    disabled={!selectedTemplate || selectedHrEmails.length === 0 || sending || !variables.your_name}
                                    className="w-full mt-6 btn-gradient px-6 py-4 rounded-lg flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                    {sending ? (
                                        <>
                                            <Loader2 className="w-5 h-5 animate-spin" />
                                            Sending...
                                        </>
                                    ) : (
                                        <>
                                            <Send className="w-5 h-5" />
                                            Send {selectedHrEmails.length} Email{selectedHrEmails.length !== 1 ? 's' : ''}
                                        </>
                                    )}
                                </button>

                                {sending && (
                                    <div className="mt-4 p-4 rounded-lg bg-muted/50 animate-pulse">
                                        <p className="text-xs text-muted-foreground text-center">
                                            Sending emails with 3s delay between each...
                                        </p>
                                    </div>
                                )}
                            </div>

                            {/* Info Card */}
                            <div className="glass-card p-6">
                                <h3 className="font-semibold mb-3 flex items-center gap-2">
                                    <CheckCircle className="w-5 h-5 text-green-500" />
                                    Safety Features
                                </h3>
                                <ul className="text-sm text-muted-foreground space-y-2">
                                    <li>• Individual emails (no CC/BCC)</li>
                                    <li>• 3-second delay between sends</li>
                                    <li>• Gmail API rate limiting</li>
                                    <li>• All emails logged</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </DashboardLayout>
        </ProtectedRoute>
    );
}
