'use client';

import { useEffect, useState } from 'react';
import ProtectedRoute from '@/components/ProtectedRoute';
import DashboardLayout from '@/components/DashboardLayout';
import { Plus, Pencil, Trash2, Eye, FileText, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

export default function TemplatesPage() {
    const [templates, setTemplates] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showModal, setShowModal] = useState(false);
    const [currentTemplate, setCurrentTemplate] = useState(null);
    const [formData, setFormData] = useState({ name: '', subject: '', body: '' });
    const [preview, setPreview] = useState(null);

    useEffect(() => {
        fetchTemplates();
    }, []);

    const fetchTemplates = async () => {
        try {
            const response = await fetch('/api/templates');
            if (response.ok) {
                const data = await response.json();
                setTemplates(data);
            } else {
                toast.error('Failed to load templates');
            }
        } catch (error) {
            console.error('Error:', error);
            toast.error('Failed to load templates');
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const url = currentTemplate
            ? `/api/templates/${currentTemplate._id}`
            : '/api/templates';
        const method = currentTemplate ? 'PUT' : 'POST';

        try {
            const response = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData),
            });

            if (response.ok) {
                toast.success(currentTemplate ? 'Template updated!' : 'Template created!');
                setShowModal(false);
                setFormData({ name: '', subject: '', body: '' });
                setCurrentTemplate(null);
                fetchTemplates();
            } else {
                toast.error('Failed to save template');
            }
        } catch (error) {
            console.error('Error:', error);
            toast.error('Something went wrong');
        }
    };

    const handleDelete = async (id) => {
        if (!confirm('Are you sure you want to delete this template?')) return;

        try {
            const response = await fetch(`/api/templates/${id}`, { method: 'DELETE' });
            if (response.ok) {
                toast.success('Template deleted');
                fetchTemplates();
            } else {
                toast.error('Failed to delete template');
            }
        } catch (error) {
            console.error('Error:', error);
            toast.error('Something went wrong');
        }
    };

    const handleEdit = (template) => {
        setCurrentTemplate(template);
        setFormData({
            name: template.name,
            subject: template.subject,
            body: template.body,
        });
        setShowModal(true);
    };

    const handlePreview = (template) => {
        setPreview(template);
    };

    return (
        <ProtectedRoute>
            <DashboardLayout>
                <div className="max-w-7xl mx-auto animate-fade-in">
                    {/* Header */}
                    <div className="flex items-center justify-between mb-8">
                        <div>
                            <h1 className="text-3xl font-bold mb-2 gradient-text">Email Templates</h1>
                            <p className="text-muted-foreground">
                                Create and manage reusable email templates with variables
                            </p>
                        </div>
                        <button
                            onClick={() => {
                                setCurrentTemplate(null);
                                setFormData({ name: '', subject: '', body: '' });
                                setShowModal(true);
                            }}
                            className="btn-gradient px-6 py-3 rounded-lg flex items-center gap-2"
                        >
                            <Plus className="w-5 h-5" />
                            New Template
                        </button>
                    </div>

                    {/* Templates Grid */}
                    {loading ? (
                        <div className="flex items-center justify-center h-64">
                            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                        </div>
                    ) : templates.length === 0 ? (
                        <div className="glass-card p-12 text-center">
                            <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
                            <h3 className="text-xl font-semibold mb-2">No templates yet</h3>
                            <p className="text-muted-foreground mb-6">
                                Create your first email template to get started
                            </p>
                            <button
                                onClick={() => setShowModal(true)}
                                className="btn-gradient px-6 py-3 rounded-lg inline-flex items-center gap-2"
                            >
                                <Plus className="w-5 h-5" />
                                Create Template
                            </button>
                        </div>
                    ) : (
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {templates.map((template, index) => (
                                <div
                                    key={template._id}
                                    className="glass-card p-6 hover-lift card-hover animate-scale-in"
                                    style={{ animationDelay: `${index * 50}ms` }}
                                >
                                    <div className="flex items-start justify-between mb-4">
                                        <div className="w-12 h-12 rounded-xl gradient-bg-primary flex items-center justify-center glow-primary">
                                            <FileText className="w-6 h-6 text-white" />
                                        </div>
                                        <div className="flex gap-2">
                                            <button
                                                onClick={() => handlePreview(template)}
                                                className="p-2 rounded-lg hover:bg-muted transition-colors"
                                                title="Preview"
                                            >
                                                <Eye className="w-4 h-4" />
                                            </button>
                                            <button
                                                onClick={() => handleEdit(template)}
                                                className="p-2 rounded-lg hover:bg-muted transition-colors"
                                                title="Edit"
                                            >
                                                <Pencil className="w-4 h-4" />
                                            </button>
                                            <button
                                                onClick={() => handleDelete(template._id)}
                                                className="p-2 rounded-lg hover:bg-destructive/10 hover:text-destructive transition-colors"
                                                title="Delete"
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </button>
                                        </div>
                                    </div>
                                    <h3 className="font-semibold text-lg mb-2 truncate">{template.name}</h3>
                                    <p className="text-sm text-muted-foreground mb-3 truncate">
                                        Subject: {template.subject}
                                    </p>
                                    <div className="flex items-center justify-between pt-3 border-t border-border/50">
                                        <span className="text-xs text-muted-foreground">
                                            Used {template.usageCount || 0} times
                                        </span>
                                        {template.variables && template.variables.length > 0 && (
                                            <div className="flex items-center gap-1 text-xs text-primary">
                                                <Sparkles className="w-3 h-3" />
                                                {template.variables.length} vars
                                            </div>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}

                    {/* Create/Edit Modal */}
                    {showModal && (
                        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm animate-fade-in">
                            <div className="glass-card max-w-3xl w-full max-h-[90vh] overflow-y-auto p-8 animate-scale-in">
                                <h2 className="text-2xl font-bold mb-6 gradient-text">
                                    {currentTemplate ? 'Edit Template' : 'Create New Template'}
                                </h2>
                                <form onSubmit={handleSubmit} className="space-y-6">
                                    <div>
                                        <label className="block text-sm font-medium mb-2">Template Name</label>
                                        <input
                                            type="text"
                                            value={formData.name}
                                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                            className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                            placeholder="e.g., Frontend Developer Application"
                                            required
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium mb-2">Email Subject</label>
                                        <input
                                            type="text"
                                            value={formData.subject}
                                            onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                                            className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                            placeholder="Application for {{job_role}} at {{company}}"
                                            required
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium mb-2">Email Body</label>
                                        <textarea
                                            value={formData.body}
                                            onChange={(e) => setFormData({ ...formData, body: e.target.value })}
                                            className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                            rows={12}
                                            placeholder={'Dear {{hr_name}},\n\nI am writing to express my interest in the {{job_role}} position at {{company}}.\n\nYou can find my resume here: {{resume_link}}\n\nBest regards,\n{{your_name}}'}
                                            required
                                        />
                                        <p className="text-xs text-muted-foreground mt-2">
                                            Available variables: {'{'}{'{'}}hr_name{'}'}{'}'}, {'{'}{'{'}}company{'}'}{'}'}, {'{'}{'{'}}job_role{'}'}{'}'}, {'{'}{'{'}}your_name{'}'}{'}'}, {'{'}{'{'}}resume_link{'}'}{'}'}, {'{'}{'{'}}portfolio_link{'}'}{'}'}
                                        </p>
                                    </div>

                                    <div className="flex gap-4">
                                        <button
                                            type="submit"
                                            className="btn-gradient px-6 py-3 rounded-lg flex-1"
                                        >
                                            {currentTemplate ? 'Update Template' : 'Create Template'}
                                        </button>
                                        <button
                                            type="button"
                                            onClick={() => {
                                                setShowModal(false);
                                                setCurrentTemplate(null);
                                                setFormData({ name: '', subject: '', body: '' });
                                            }}
                                            className="px-6 py-3 rounded-lg border border-border hover:bg-muted transition-colors"
                                        >
                                            Cancel
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    )}

                    {/* Preview Modal */}
                    {preview && (
                        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm animate-fade-in" onClick={() => setPreview(null)}>
                            <div className="glass-card max-w-3xl w-full max-h-[90vh] overflow-y-auto p-8 animate-scale-in" onClick={(e) => e.stopPropagation()}>
                                <div className="flex items-center justify-between mb-6">
                                    <h2 className="text-2xl font-bold gradient-text">{preview.name}</h2>
                                    <button
                                        onClick={() => setPreview(null)}
                                        className="px-4 py-2 rounded-lg border border-border hover:bg-muted transition-colors"
                                    >
                                        Close
                                    </button>
                                </div>
                                <div className="space-y-4">
                                    <div>
                                        <p className="text-sm font-medium text-muted-foreground mb-2">Subject:</p>
                                        <p className="font-medium">{preview.subject}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm font-medium text-muted-foreground mb-2">Body:</p>
                                        <div className="p-4 rounded-lg bg-muted/50 whitespace-pre-wrap font-mono text-sm">
                                            {preview.body}
                                        </div>
                                    </div>
                                    {preview.variables && preview.variables.length > 0 && (
                                        <div>
                                            <p className="text-sm font-medium text-muted-foreground mb-2">Variables:</p>
                                            <div className="flex flex-wrap gap-2">
                                                {preview.variables.map((variable) => (
                                                    <span
                                                        key={variable}
                                                        className="px-3 py-1 rounded-full bg-primary/10 text-primary text-sm border border-primary/20"
                                                    >
                                                        {'{'}{'{'}{variable}{'}}{'}'}
                                                    </span>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </DashboardLayout>
        </ProtectedRoute>
    );
}
