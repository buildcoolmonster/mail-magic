'use client';

import { useEffect, useState } from 'react';
import ProtectedRoute from '@/components/ProtectedRoute';
import DashboardLayout from '@/components/DashboardLayout';
import { Plus, Upload, Pencil, Trash2, Users, FileSpreadsheet } from 'lucide-react';
import { toast } from 'sonner';

export default function HrEmailsPage() {
    const [hrEmails, setHrEmails] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showModal, setShowModal] = useState(false);
    const [showImportModal, setShowImportModal] = useState(false);
    const [currentEmail, setCurrentEmail] = useState(null);
    const [formData, setFormData] = useState({
        email: '',
        hrName: '',
        company: '',
        jobRole: '',
        notes: '',
    });

    useEffect(() => {
        fetchHrEmails();
    }, []);

    const fetchHrEmails = async () => {
        try {
            const response = await fetch('/api/hr-emails');
            if (response.ok) {
                const data = await response.json();
                setHrEmails(data);
            } else {
                toast.error('Failed to load HR emails');
            }
        } catch (error) {
            console.error('Error:', error);
            toast.error('Failed to load HR emails');
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const url = currentEmail
            ? `/api/hr-emails/${currentEmail._id}`
            : '/api/hr-emails';
        const method = currentEmail ? 'PUT' : 'POST';

        try {
            const response = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData),
            });

            if (response.ok) {
                toast.success(currentEmail ? 'Contact updated!' : 'Contact added!');
                setShowModal(false);
                setFormData({ email: '', hrName: '', company: '', jobRole: '', notes: '' });
                setCurrentEmail(null);
                fetchHrEmails();
            } else {
                const error = await response.json();
                toast.error(error.error || 'Failed to save contact');
            }
        } catch (error) {
            console.error('Error:', error);
            toast.error('Something went wrong');
        }
    };

    const handleDelete = async (id) => {
        if (!confirm('Are you sure you want to delete this contact?')) return;

        try {
            const response = await fetch(`/api/hr-emails/${id}`, { method: 'DELETE' });
            if (response.ok) {
                toast.success('Contact deleted');
                fetchHrEmails();
            } else {
                toast.error('Failed to delete contact');
            }
        } catch (error) {
            console.error('Error:', error);
            toast.error('Something went wrong');
        }
    };

    const handleEdit = (email) => {
        setCurrentEmail(email);
        setFormData({
            email: email.email,
            hrName: email.hrName || '',
            company: email.company || '',
            jobRole: email.jobRole || '',
            notes: email.notes || '',
        });
        setShowModal(true);
    };

    const handleImport = async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch('/api/hr-emails/import', {
                method: 'POST',
                body: formData,
            });

            if (response.ok) {
                const result = await response.json();
                toast.success(`Imported ${result.imported} contacts! Skipped ${result.skipped}, Errors ${result.errors}`);
                setShowImportModal(false);
                fetchHrEmails();
            } else {
                toast.error('Failed to import CSV');
            }
        } catch (error) {
            console.error('Error:', error);
            toast.error('Something went wrong');
        }
    };

    return (
        <ProtectedRoute>
            <DashboardLayout>
                <div className="max-w-7xl mx-auto animate-fade-in">
                    {/* Header */}
                    <div className="flex items-center justify-between mb-8">
                        <div>
                            <h1 className="text-3xl font-bold mb-2 gradient-text">HR Contacts</h1>
                            <p className="text-muted-foreground">
                                Manage your recruiter and HR email contacts
                            </p>
                        </div>
                        <div className="flex gap-3">
                            <button
                                onClick={() => setShowImportModal(true)}
                                className="px-6 py-3 rounded-lg border border-border hover:bg-muted transition-colors flex items-center gap-2"
                            >
                                <Upload className="w-5 h-5" />
                                Import CSV
                            </button>
                            <button
                                onClick={() => {
                                    setCurrentEmail(null);
                                    setFormData({ email: '', hrName: '', company: '', jobRole: '', notes: '' });
                                    setShowModal(true);
                                }}
                                className="btn-gradient px-6 py-3 rounded-lg flex items-center gap-2"
                            >
                                <Plus className="w-5 h-5" />
                                Add Contact
                            </button>
                        </div>
                    </div>

                    {/* HR Emails List */}
                    {loading ? (
                        <div className="flex items-center justify-center h-64">
                            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                        </div>
                    ) : hrEmails.length === 0 ? (
                        <div className="glass-card p-12 text-center">
                            <Users className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
                            <h3 className="text-xl font-semibold mb-2">No contacts yet</h3>
                            <p className="text-muted-foreground mb-6">
                                Add HR contacts manually or import from CSV
                            </p>
                            <div className="flex gap-4 justify-center">
                                <button
                                    onClick={() => setShowModal(true)}
                                    className="btn-gradient px-6 py-3 rounded-lg inline-flex items-center gap-2"
                                >
                                    <Plus className="w-5 h-5" />
                                    Add Contact
                                </button>
                                <button
                                    onClick={() => setShowImportModal(true)}
                                    className="px-6 py-3 rounded-lg border border-border hover:bg-muted transition-colors inline-flex items-center gap-2"
                                >
                                    <Upload className="w-5 h-5" />
                                    Import CSV
                                </button>
                            </div>
                        </div>
                    ) : (
                        <div className="glass-card overflow-hidden">
                            <div className="overflow-x-auto">
                                <table className="w-full">
                                    <thead>
                                        <tr className="border-b border-border/50">
                                            <th className="text-left p-4 font-semibold">Email</th>
                                            <th className="text-left p-4 font-semibold">HR Name</th>
                                            <th className="text-left p-4 font-semibold">Company</th>
                                            <th className="text-left p-4 font-semibold">Job Role</th>
                                            <th className="text-left p-4 font-semibold">Status</th>
                                            <th className="text-right p-4 font-semibold">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {hrEmails.map((email, index) => (
                                            <tr
                                                key={email._id}
                                                className="border-b border-border/30 hover:bg-muted/30 transition-colors animate-scale-in"
                                                style={{ animationDelay: `${index * 30}ms` }}
                                            >
                                                <td className="p-4">{email.email}</td>
                                                <td className="p-4">{email.hrName || '-'}</td>
                                                <td className="p-4">{email.company || '-'}</td>
                                                <td className="p-4">{email.jobRole || '-'}</td>
                                                <td className="p-4">
                                                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${email.status === 'contacted'
                                                            ? 'bg-green-500/10 text-green-500 border border-green-500/20'
                                                            : 'bg-blue-500/10 text-blue-500 border border-blue-500/20'
                                                        }`}>
                                                        {email.status || 'active'}
                                                    </span>
                                                </td>
                                                <td className="p-4">
                                                    <div className="flex gap-2 justify-end">
                                                        <button
                                                            onClick={() => handleEdit(email)}
                                                            className="p-2 rounded-lg hover:bg-muted transition-colors"
                                                            title="Edit"
                                                        >
                                                            <Pencil className="w-4 h-4" />
                                                        </button>
                                                        <button
                                                            onClick={() => handleDelete(email._id)}
                                                            className="p-2 rounded-lg hover:bg-destructive/10 hover:text-destructive transition-colors"
                                                            title="Delete"
                                                        >
                                                            <Trash2 className="w-4 h-4" />
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}

                    {/* Add/Edit Modal */}
                    {showModal && (
                        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm animate-fade-in">
                            <div className="glass-card max-w-2xl w-full p-8 animate-scale-in">
                                <h2 className="text-2xl font-bold mb-6 gradient-text">
                                    {currentEmail ? 'Edit Contact' : 'Add New Contact'}
                                </h2>
                                <form onSubmit={handleSubmit} className="space-y-4">
                                    <div>
                                        <label className="block text-sm font-medium mb-2">Email Address *</label>
                                        <input
                                            type="email"
                                            value={formData.email}
                                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                            className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                            placeholder="hr@company.com"
                                            required
                                        />
                                    </div>

                                    <div className="grid md:grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-sm font-medium mb-2">HR Name</label>
                                            <input
                                                type="text"
                                                value={formData.hrName}
                                                onChange={(e) => setFormData({ ...formData, hrName: e.target.value })}
                                                className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                                placeholder="John Doe"
                                            />
                                        </div>

                                        <div>
                                            <label className="block text-sm font-medium mb-2">Company</label>
                                            <input
                                                type="text"
                                                value={formData.company}
                                                onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                                                className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                                placeholder="Acme Inc"
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium mb-2">Job Role</label>
                                        <input
                                            type="text"
                                            value={formData.jobRole}
                                            onChange={(e) => setFormData({ ...formData, jobRole: e.target.value })}
                                            className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                            placeholder="Frontend Developer"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium mb-2">Notes</label>
                                        <textarea
                                            value={formData.notes}
                                            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                                            className="w-full px-4 py-3 rounded-lg bg-muted border border-border focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                                            rows={3}
                                            placeholder="Any additional notes..."
                                        />
                                    </div>

                                    <div className="flex gap-4 pt-4">
                                        <button
                                            type="submit"
                                            className="btn-gradient px-6 py-3 rounded-lg flex-1"
                                        >
                                            {currentEmail ? 'Update Contact' : 'Add Contact'}
                                        </button>
                                        <button
                                            type="button"
                                            onClick={() => {
                                                setShowModal(false);
                                                setCurrentEmail(null);
                                                setFormData({ email: '', hrName: '', company: '', jobRole: '', notes: '' });
                                            }}
                                            className="px-6 py-3 rounded-lg border border-border hover:bg-muted transition-colors"
                                        >
                                            Cancel
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    )}

                    {/* Import Modal */}
                    {showImportModal && (
                        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm animate-fade-in">
                            <div className="glass-card max-w-2xl w-full p-8 animate-scale-in">
                                <h2 className="text-2xl font-bold mb-6 gradient-text">Import from CSV</h2>
                                <div className="space-y-6">
                                    <div>
                                        <p className="text-muted-foreground mb-4">
                                            Upload a CSV file with the following columns:
                                        </p>
                                        <div className="bg-muted/50 p-4 rounded-lg font-mono text-sm">
                                            email, hrName, company, jobRole, notes
                                        </div>
                                    </div>

                                    <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                                        <FileSpreadsheet className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                                        <label className="cursor-pointer">
                                            <span className="btn-gradient px-6 py-3 rounded-lg inline-flex items-center gap-2">
                                                <Upload className="w-5 h-5" />
                                                Choose CSV File
                                            </span>
                                            <input
                                                type="file"
                                                accept=".csv"
                                                onChange={handleImport}
                                                className="hidden"
                                            />
                                        </label>
                                    </div>

                                    <button
                                        onClick={() => setShowImportModal(false)}
                                        className="w-full px-6 py-3 rounded-lg border border-border hover:bg-muted transition-colors"
                                    >
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </DashboardLayout>
        </ProtectedRoute>
    );
}
