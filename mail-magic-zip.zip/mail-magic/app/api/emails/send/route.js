import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import dbConnect from '@/lib/mongodb';
import EmailLog from '@/models/EmailLog';
import EmailTemplate from '@/models/EmailTemplate';
import HrEmail from '@/models/HrEmail';
import User from '@/models/User';
import GmailService from '@/lib/gmail';
import { replaceVariables } from '@/lib/utils';
import { NextResponse } from 'next/server';

export async function POST(request) {
    try {
        const session = await getServerSession(authOptions);

        if (!session) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const body = await request.json();
        const { templateId, hrEmailIds, variables, attachResume } = body;

        if (!templateId || !hrEmailIds || hrEmailIds.length === 0) {
            return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
        }

        await dbConnect();

        // Get template
        const template = await EmailTemplate.findOne({
            _id: templateId,
            userId: session.user.id,
        });

        if (!template) {
            return NextResponse.json({ error: 'Template not found' }, { status: 404 });
        }

        // Get HR emails
        const hrEmails = await HrEmail.find({
            _id: { $in: hrEmailIds },
            userId: session.user.id,
        });

        if (hrEmails.length === 0) {
            return NextResponse.json({ error: 'No valid recipients found' }, { status: 404 });
        }

        // Get user for Gmail API
        const user = await User.findById(session.user.id);
        if (!user || !user.accessToken || !user.refreshToken) {
            return NextResponse.json({ error: 'Gmail authentication required' }, { status: 401 });
        }

        // Prepare attachment if requested
        let attachment = null;
        if (attachResume && user.resume && user.resume.data) {
            attachment = {
                filename: user.resume.filename,
                mimeType: user.resume.mimeType,
                data: user.resume.data, // Already base64 encoded
            };
        }

        // Initialize Gmail service
        const gmailService = new GmailService(user.accessToken, user.refreshToken);

        const results = {
            sent: [],
            failed: [],
            total: hrEmails.length,
        };

        // Get delay setting
        const delay = user.settings?.emailDelay || 3000;

        // Send emails sequentially
        for (const hrEmail of hrEmails) {
            try {
                // Prepare variables for this email
                const emailVariables = {
                    ...variables,
                    hr_name: hrEmail.hrName || 'Hiring Manager',
                    company: hrEmail.company || '',
                    job_role: hrEmail.jobRole || '',
                };

                // Replace variables in subject and body
                const subject = replaceVariables(template.subject, emailVariables);
                const emailBody = replaceVariables(template.body, emailVariables);

                // Send email with optional attachment
                const result = await gmailService.sendEmail({
                    to: hrEmail.email,
                    subject,
                    body: emailBody,
                    from: user.email,
                    attachment, // Will be null if no resume or not requested
                });

                // Create log entry
                const log = await EmailLog.create({
                    userId: session.user.id,
                    templateId: template._id,
                    hrEmailId: hrEmail._id,
                    recipient: hrEmail.email,
                    subject,
                    body: emailBody,
                    status: result.success ? 'sent' : 'failed',
                    errorMessage: result.error || null,
                    gmailMessageId: result.messageId || null,
                    gmailThreadId: result.threadId || null,
                    sentAt: result.success ? new Date() : null,
                });

                if (result.success) {
                    results.sent.push({
                        email: hrEmail.email,
                        logId: log._id,
                    });

                    // Update HR email lastContacted
                    hrEmail.lastContacted = new Date();
                    hrEmail.status = 'contacted';
                    await hrEmail.save();
                } else {
                    results.failed.push({
                        email: hrEmail.email,
                        error: result.error,
                        logId: log._id,
                    });
                }

                // Wait before sending next email
                if (hrEmails.indexOf(hrEmail) < hrEmails.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            } catch (error) {
                console.error(`Error sending to ${hrEmail.email}:`, error);
                results.failed.push({
                    email: hrEmail.email,
                    error: error.message,
                });
            }
        }

        // Update template usage count
        template.usageCount += 1;
        await template.save();

        return NextResponse.json({
            success: true,
            results,
        });
    } catch (error) {
        console.error('Error sending emails:', error);
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}
