'use client';

import { useEffect, useState } from 'react';
import ProtectedRoute from '@/components/ProtectedRoute';
import DashboardLayout from '@/components/DashboardLayout';
import { ListChecks, CheckCircle2, XCircle, Filter, Download } from 'lucide-react';
import { toast } from 'sonner';
import { formatDate, getStatusBadgeClass } from '@/lib/utils';

export default function LogsPage() {
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState('all');
    const [selectedLog, setSelectedLog] = useState(null);

    useEffect(() => {
        fetchLogs();
    }, [filter]);

    const fetchLogs = async () => {
        setLoading(true);
        try {
            const url = filter === 'all' ? '/api/logs' : `/api/logs?status=${filter}`;
            const response = await fetch(url);
            if (response.ok) {
                const data = await response.json();
                setLogs(data.logs || []);
            } else {
                toast.error('Failed to load logs');
            }
        } catch (error) {
            console.error('Error:', error);
            toast.error('Failed to load logs');
        } finally {
            setLoading(false);
        }
    };

    const exportLogs = () => {
        const csv = [
            ['Date', 'Recipient', 'Subject', 'Status', 'Template', 'HR Name', 'Company'],
            ...logs.map((log) => [
                formatDate(log.createdAt),
                log.recipient,
                log.subject,
                log.status,
                log.templateId?.name || 'N/A',
                log.hrEmailId?.hrName || 'N/A',
                log.hrEmailId?.company || 'N/A',
            ]),
        ]
            .map((row) => row.map((cell) => `"${cell}"`).join(','))
            .join('\n');

        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `autojobmailer-logs-${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        window.URL.revokeObjectURL(url);
        toast.success('Logs exported!');
    };

    const stats = {
        total: logs.length,
        sent: logs.filter((l) => l.status === 'sent').length,
        failed: logs.filter((l) => l.status === 'failed').length,
    };

    return (
        <ProtectedRoute>
            <DashboardLayout>
                <div className="max-w-7xl mx-auto animate-fade-in">
                    {/* Header */}
                    <div className="flex items- center justify-between mb-8">
                        <div>
                            <h1 className="text-3xl font-bold mb-2 gradient-text">Email Logs</h1>
                            <p className="text-muted-foreground">
                                Track all your sent job application emails
                            </p>
                        </div>
                        <button
                            onClick={exportLogs}
                            disabled={logs.length === 0}
                            className="px-6 py-3 rounded-lg border border-border hover:bg-muted transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            <Download className="w-5 h-5" />
                            Export CSV
                        </button>
                    </div>

                    {/* Stats */}
                    <div className="grid md:grid-cols-3 gap-6 mb-8">
                        <div className="glass-card p-6">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center border border-blue-500/20">
                                    <ListChecks className="w-6 h-6 text-blue-500" />
                                </div>
                                <div>
                                    <p className="text-2xl font-bold">{stats.total}</p>
                                    <p className="text-sm text-muted-foreground">Total Emails</p>
                                </div>
                            </div>
                        </div>

                        <div className="glass-card p-6">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-xl bg-green-500/10 flex items-center justify-center border border-green-500/20">
                                    <CheckCircle2 className="w-6 h-6 text-green-500" />
                                </div>
                                <div>
                                    <p className="text-2xl font-bold">{stats.sent}</p>
                                    <p className="text-sm text-muted-foreground">Successfully Sent</p>
                                </div>
                            </div>
                        </div>

                        <div className="glass-card p-6">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center border border-red-500/20">
                                    <XCircle className="w-6 h-6 text-red-500" />
                                </div>
                                <div>
                                    <p className="text-2xl font-bold">{stats.failed}</p>
                                    <p className="text-sm text-muted-foreground">Failed</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Filters */}
                    <div className="glass-card p-4 mb-6">
                        <div className="flex items-center gap-4">
                            <Filter className="w-5 h-5 text-muted-foreground" />
                            <div className="flex gap-2">
                                {['all', 'sent', 'failed'].map((status) => (
                                    <button
                                        key={status}
                                        onClick={() => setFilter(status)}
                                        className={`px-4 py-2 rounded-lg transition-colors ${filter === status
                                                ? 'gradient-bg-primary text-white'
                                                : 'hover:bg-muted text-muted-foreground'
                                            }`}
                                    >
                                        {status.charAt(0).toUpperCase() + status.slice(1)}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Logs Table */}
                    {loading ? (
                        <div className="flex items-center justify-center h-64">
                            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                        </div>
                    ) : logs.length === 0 ? (
                        <div className="glass-card p-12 text-center">
                            <ListChecks className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
                            <h3 className="text-xl font-semibold mb-2">No logs yet</h3>
                            <p className="text-muted-foreground mb-6">
                                Start sending emails to see logs here
                            </p>
                        </div>
                    ) : (
                        <div className="glass-card overflow-hidden">
                            <div className="overflow-x-auto">
                                <table className="w-full">
                                    <thead>
                                        <tr className="border-b border-border/50">
                                            <th className="text-left p-4 font-semibold">Date</th>
                                            <th className="text-left p-4 font-semibold">Recipient</th>
                                            <th className="text-left p-4 font-semibold">Subject</th>
                                            <th className="text-left p-4 font-semibold">Template</th>
                                            <th className="text-left p-4 font-semibold">Status</th>
                                            <th className="text-right p-4 font-semibold">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {logs.map((log, index) => (
                                            <tr
                                                key={log._id}
                                                className="border-b border-border/30 hover:bg-muted/30 transition-colors animate-scale-in"
                                                style={{ animationDelay: `${index * 30}ms` }}
                                            >
                                                <td className="p-4 text-sm text-muted-foreground">
                                                    {formatDate(log.createdAt)}
                                                </td>
                                                <td className="p-4">
                                                    <div>
                                                        <p className="font-medium">{log.recipient}</p>
                                                        {log.hrEmailId && (
                                                            <p className="text-sm text-muted-foreground">
                                                                {log.hrEmailId.hrName}
                                                            </p>
                                                        )}
                                                    </div>
                                                </td>
                                                <td className="p-4">
                                                    <p className="truncate max-w-xs">{log.subject}</p>
                                                </td>
                                                <td className="p-4 text-sm text-muted-foreground">
                                                    {log.templateId?.name || 'N/A'}
                                                </td>
                                                <td className="p-4">
                                                    <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusBadgeClass(log.status)}`}>
                                                        {log.status}
                                                    </span>
                                                </td>
                                                <td className="p-4">
                                                    <div className="flex justify-end">
                                                        <button
                                                            onClick={() => setSelectedLog(log)}
                                                            className="text-sm text-primary hover:underline"
                                                        >
                                                            View
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}

                    {/* Log Detail Modal */}
                    {selectedLog && (
                        <div
                            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm animate-fade-in"
                            onClick={() => setSelectedLog(null)}
                        >
                            <div className="glass-card max-w-3xl w-full max-h-[90vh] overflow-y-auto p-8 animate-scale-in" onClick={(e) => e.stopPropagation()}>
                                <div className="flex items-center justify-between mb-6">
                                    <h2 className="text-2xl font-bold gradient-text">Email Details</h2>
                                    <button
                                        onClick={() => setSelectedLog(null)}
                                        className="px-4 py-2 rounded-lg border border-border hover:bg-muted transition-colors"
                                    >
                                        Close
                                    </button>
                                </div>

                                <div className="space-y-6">
                                    <div className="grid md:grid-cols-2 gap-4">
                                        <div>
                                            <p className="text-xs font-medium text-muted-foreground mb-1">Recipient:</p>
                                            <p className="font-medium">{selectedLog.recipient}</p>
                                        </div>
                                        <div>
                                            <p className="text-xs font-medium text-muted-foreground mb-1">Status:</p>
                                            <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium border ${getStatusBadgeClass(selectedLog.status)}`}>
                                                {selectedLog.status}
                                            </span>
                                        </div>
                                        <div>
                                            <p className="text-xs font-medium text-muted-foreground mb-1">Sent At:</p>
                                            <p className="font-medium">{formatDate(selectedLog.createdAt)}</p>
                                        </div>
                                        <div>
                                            <p className="text-xs font-medium text-muted-foreground mb-1">Template:</p>
                                            <p className="font-medium">{selectedLog.templateId?.name || 'N/A'}</p>
                                        </div>
                                    </div>

                                    {selectedLog.hrEmailId && (
                                        <div>
                                            <p className="text-xs font-medium text-muted-foreground mb-2">HR Details:</p>
                                            <div className="p-4 rounded-lg bg-muted/50">
                                                <p><span className="text-muted-foreground">Name:</span> {selectedLog.hrEmailId.hrName || 'N/A'}</p>
                                                <p><span className="text-muted-foreground">Company:</span> {selectedLog.hrEmailId.company || 'N/A'}</p>
                                                <p><span className="text-muted-foreground">Job Role:</span> {selectedLog.hrEmailId.jobRole || 'N/A'}</p>
                                            </div>
                                        </div>
                                    )}

                                    <div>
                                        <p className="text-xs font-medium text-muted-foreground mb-2">Subject:</p>
                                        <p className="font-medium">{selectedLog.subject}</p>
                                    </div>

                                    <div>
                                        <p className="text-xs font-medium text-muted-foreground mb-2">Body:</p>
                                        <div className="p-4 rounded-lg bg-muted/50 whitespace-pre-wrap text-sm max-h-64 overflow-y-auto">
                                            {selectedLog.body}
                                        </div>
                                    </div>

                                    {selectedLog.errorMessage && (
                                        <div>
                                            <p className="text-xs font-medium text-destructive mb-2">Error:</p>
                                            <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/20 text-sm">
                                                {selectedLog.errorMessage}
                                            </div>
                                        </div>
                                    )}

                                    {selectedLog.gmailMessageId && (
                                        <div>
                                            <p className="text-xs font-medium text-muted-foreground mb-1">Gmail Message ID:</p>
                                            <p className="text-sm font-mono text-muted-foreground">{selectedLog.gmailMessageId}</p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </DashboardLayout>
        </ProtectedRoute>
    );
}
